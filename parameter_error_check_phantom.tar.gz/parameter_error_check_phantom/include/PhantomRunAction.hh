#ifndef PhantomRunAction_h
#define PhantomRunAction_h

#include "G4UserRunAction.hh"

class G4Run;

class PhantomRunAction : public G4UserRunAction
{
public:
  PhantomRunAction();
  virtual ~PhantomRunAction();

  virtual void BeginOfRunAction(const G4Run*);
  virtual void   EndOfRunAction(const G4Run*);
  
  void IncrementPhotonCount(G4double);
  void IncrementPhotonKillCount() {++fNKill;}
  void IncrementPhotonCount() {++fPhotonCount;}
  G4double GetPhotonCount() {return fNPhotons;}
  G4double GetPhotonKillCount() {return fNKill;}
  G4double GetDose() {return fDose;}
  G4double GetDose2() {return fDose2;}
  void AddDose(G4double addDose) {fDose = fDose + addDose;} 
  void SetDose2(G4double Dose2) {fDose2 = Dose2;} 

 private:
  static PhantomRunAction* fpMasterRunAction;
  G4double fNPhotons;
  G4double fPhotonCount;
  G4double fNKill;
  G4double fDose;
  G4double fDose2;
};

#endif


#ifndef PhantomDetectorConstruction_h
#define PhantomDetectorConstruction_h 1

#include "G4VUserDetectorConstruction.hh"
class PhantomDetectorConstructionMessenger;
class G4VPhysicalVolume;
class G4LogicalVolume;

class PhantomDetectorConstruction : public G4VUserDetectorConstruction
{
public:
  PhantomDetectorConstruction();
  virtual ~PhantomDetectorConstruction();

  virtual G4VPhysicalVolume* Construct();
  void ConstructSDandField();

  G4VPhysicalVolume* GetFibrePhys() const {return fpFibre_phys;}
  G4VPhysicalVolume* GetScintPhys() const {return fscint_phys;}
  G4VPhysicalVolume* GetOrbPhys() const {return forb_phys;}
  G4VPhysicalVolume* GetShieldPhys() const {return fshield_phys;}
  G4LogicalVolume* GetScintLog() const {return fscint_log;}
  G4LogicalVolume* GetCore() const {return fcore_log;}
  G4VPhysicalVolume* GetClad() const {return fcore_phys;}

  void set_cable_length(G4double val) {cable_length = val;}
  void set_shield_length(G4double val) {shield_length = val;}
  void set_voxel_half_side(G4double val) {voxel_half_side = val;}
  void set_bend_radius(G4double val) {bend_radius = val;}
  void set_birk_constant(G4double val) {EJ309_Birks_Constant = val;}
  void set_ebirk_constant(G4double val) {eEJ309_Birks_Constant = val;}
  void set_scint_abs_length(G4double val) {EJ309_abs_length = val;}
  void set_escint_abs_length(G4double val) {eEJ309_abs_length = val;}
  void set_core_RI(G4double val) {core_RI = val;}
  void set_clad_RI(G4double val) {clad_RI = val;}
  void set_shield_RI(G4double val) {shield_RI = val;}
  G4double get_cable_length() const {return cable_length;}
  G4double get_shield_length() const {return shield_length;}
  G4double get_detector_y() const {return (1.9*cable_length+bend_radius);}
  G4double get_detector_z() const {return (voxel_half_side);}    

private:
  PhantomDetectorConstructionMessenger* fMessenger;
  G4LogicalVolume* fpFibre_log;
  G4VPhysicalVolume* fpFibre_phys;
  G4VPhysicalVolume* fscint_phys;
  G4LogicalVolume* fscint_log;
  G4VPhysicalVolume* forb_phys;
  G4LogicalVolume* fcore_log;
  G4VPhysicalVolume* fcore_phys;
  G4LogicalVolume* fshield_log;
  G4VPhysicalVolume* fshield_phys;
  G4double EJ309_Birks_Constant;
  G4double EJ309_abs_length;
  G4double core_RI;
  G4double clad_RI;
  G4double shield_RI;
  G4double cable_length; 
  G4double shield_length; 
  G4double voxel_half_side; 
  G4double bend_radius; 
  G4double core_rad;
  G4double clad_rad; //Note, haven't put the fibre radii in the detector construction yet.
  G4double eEJ309_Birks_Constant;
  G4double eEJ309_abs_length;
  G4double ecore_RI;
  G4double eclad_RI;
  G4double eshield_RI;
  G4double ecable_length; 
  G4double eshield_length; 
  G4double evoxel_half_side; 
  G4double ebend_radius; 
  G4double ecore_rad;
  G4double eclad_rad;
};

#endif


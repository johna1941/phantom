#include "PhantomSteppingAction.hh"

#include "PhantomRunAction.hh"
#include "PhantomDetectorConstruction.hh"
#include "G4Track.hh"
#include "G4OpticalPhoton.hh"
#include "G4RunManager.hh"
#include "G4SystemOfUnits.hh"
#include "G4PhysicalConstants.hh"

#include <cmath>

namespace {
  G4VPhysicalVolume* pFibre_phys = 0;
  G4VPhysicalVolume* pScint_phys = 0;
  G4VPhysicalVolume* pShield_phys = 0;
  G4LogicalVolume* pScint_log = 0;
  G4double detector_y = 0;
  G4double detector_z = 0;
}

PhantomSteppingAction::PhantomSteppingAction(PhantomRunAction* runAction)
: fpRunAction(runAction)
{
  pFibre_phys =
  static_cast<const PhantomDetectorConstruction*>
  (G4RunManager::GetRunManager()->GetUserDetectorConstruction())->
  GetFibrePhys();

  pScint_phys =
  static_cast<const PhantomDetectorConstruction*>
  (G4RunManager::GetRunManager()->GetUserDetectorConstruction())->
  GetScintPhys();

  pScint_log =
  static_cast<const PhantomDetectorConstruction*>
  (G4RunManager::GetRunManager()->GetUserDetectorConstruction())->
  GetScintLog();

  pShield_phys =
  static_cast<const PhantomDetectorConstruction*>
  (G4RunManager::GetRunManager()->GetUserDetectorConstruction())->
  GetShieldPhys();

  //y coord of the detector
  detector_y = static_cast<const PhantomDetectorConstruction*>(G4RunManager::GetRunManager()->GetUserDetectorConstruction())->
  get_detector_y();

  //z coord of detector
  detector_z = static_cast<const PhantomDetectorConstruction*>(G4RunManager::GetRunManager()->GetUserDetectorConstruction())->
  get_detector_z();
}

PhantomSteppingAction::~PhantomSteppingAction()
{}

void PhantomSteppingAction::UserSteppingAction(const G4Step* step)
{
    G4StepPoint* preStepPoint = step->GetPreStepPoint();
    G4StepPoint* postStepPoint = step->GetPostStepPoint();
    G4Track* track = step->GetTrack();

// DOSE COUNT VARIABLES //////////////////////////////////////////////
    if (preStepPoint->GetPhysicalVolume()== pScint_phys) {
        G4double tempEdep = step->GetTotalEnergyDeposit();
        G4double dose = tempEdep/pScint_log->GetMass();
        fpRunAction-> AddDose(dose);
        G4double dose2 = dose*dose;
        G4double currentDose2 = fpRunAction-> GetDose2();
        fpRunAction-> SetDose2(dose2 + currentDose2);
/*        if (dose != 0) { //Debugging scripts
          G4double markedDose2 = fpRunAction-> GetDose2();
          G4cout << dose2 + currentDose2 << "; dose2: " << dose2 << "; currentdose2 " << currentDose2 << "; Recorded dose: " << markedDose2 << G4endl;
}*/
    }

// PHOTON COUNT VARIABLES //////////////////////////////////////////// 
   
    //The fibre can be moved, we need to refresh the pointer
    pFibre_phys =
    static_cast<const PhantomDetectorConstruction*>
    (G4RunManager::GetRunManager()->GetUserDetectorConstruction())->
    GetFibrePhys();

    //Are we in the fibre?
    if (postStepPoint->GetPhysicalVolume() == pFibre_phys){

    // Is it an optical photon?
    const G4ParticleDefinition* pPDef = track->GetParticleDefinition();
    if (pPDef != G4OpticalPhoton::Definition()) return;

    // It's an optical photon entering the fibre
    G4double photon_energy = track->GetTotalEnergy(); //Default energy unit is MeV
    fpRunAction->IncrementPhotonCount(photon_energy); //For PDE calculation
    fpRunAction->IncrementPhotonCount(); // For error evaluation
    track->SetTrackStatus(fStopAndKill);

    }

  return;
}

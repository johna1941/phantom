#include "PhantomRunAction.hh"

#include "G4Run.hh"
#include "G4Threading.hh"
#include "G4AutoLock.hh"
#include "G4UnitsTable.hh"
#include "G4SystemOfUnits.hh"
#include "G4RunManager.hh"
//#include "PhantomDetectorConstruction.hh"

#include <cassert>
#include <fstream>
#include <math.h>

PhantomRunAction* PhantomRunAction::fpMasterRunAction = 0;

PhantomRunAction::PhantomRunAction()
: fNPhotons(0),
  fDose(0),
  fDose2(0),
  fNKill(0),
  fPhotonCount(0)
{
  // add new units for dose
  // 
  const G4double milligray = 1.e-3*gray;
  const G4double microgray = 1.e-6*gray;
  const G4double nanogray  = 1.e-9*gray;  
  const G4double picogray  = 1.e-12*gray;
   
  new G4UnitDefinition("milligray", "milliGy" , "Dose", milligray);
  new G4UnitDefinition("microgray", "microGy" , "Dose", microgray);
  new G4UnitDefinition("nanogray" , "nanoGy"  , "Dose", nanogray);
  new G4UnitDefinition("picogray" , "picoGy"  , "Dose", picogray);

   //Multi threading
  if (G4Threading::IsWorkerThread()) {
    // Worker thread.  fpMasterRunAction should have been initialised by now.
    assert(fpMasterRunAction);
  } else {
    fpMasterRunAction = this;
  }
}

PhantomRunAction::~PhantomRunAction()
{
}

//Function to increment the photon count when a photon (energy in MeV) hits the SiPM
void PhantomRunAction::IncrementPhotonCount(G4double photon_energy_MeV)
{
  G4double wavelength_nm = 1e9*(6.62607004e-34*299792458./(1.602e-13*photon_energy_MeV));

  const int ENTRY_NUMBER = 122;
  G4double photon_wavelength_array[ENTRY_NUMBER] = {303.3653846,310.0961538,311.0576923,312.9807692,314.9038462,
316.8269231,317.7884615,319.7115385,319.7115385,320.6730769,321.6346154,323.0769231,323.5576923,
324.5192308,325.4807692,325.4807692,326.4423077,326.4423078,327.4038462,328.3653846,330.2884615,
333.1730769,334.1346154,335.0961538,337.0192308,338.9423077,343.7500000,350.4807692,357.2115385,
363.9423077,369.7115385,372.5961538,375.4807692,379.3269231,383.1730769,387.0192308,392.7884615,
400.4807692,407.2115385,413.9423077,419.7115385,426.4423077,433.1730769,440.8653846,447.5961538,
452.4038462,458.1730769,462.9807692,469.7115385,475.4807692,481.2500000,484.1346154,489.9038462,
496.1538462,500.4807692,507.2115385,512.9807692,517.7884615,523.5576923,530.2884615,537.0192308,
543.7500000,549.5192308,556.2500000,563.9423077,569.7115385,577.4038462,583.1730769,590.8653846,
597.5961538,603.3653846,610.0961538,616.8269231,624.5192308,631.2500000,637.9807692,644.7115385,
651.4423077,658.1730769,664.9038462,671.6346154,678.3653846,686.0576923,692.7884615,699.5192308,
705.2884615,712.9807692,718.7500000,725.4807692,733.1730769,739.9038462,747.5961538,754.3269231,
760.0961538,766.8269231,773.5576923,781.2500000,787.9807692,794.7115385,801.4423077,809.1346154,
815.8653846,821.6346154,828.3653846,836.0576923,841.8269231,849.5192308,856.2500000,862.9807692,
869.7115385,875.4807692,883.1730769,890.8653846,896.6346154,903.3653846,910.0961538,917.3076923,
924.5192308,931.2500000,937.0192308,943.7500000,950.4807692};
  G4double PDE_array[ENTRY_NUMBER] = {0.0312086435,0.0323200993,0.0398521505,0.046851737,
0.0549265922,0.0624638131,0.0699958644,0.0775330852,0.0850599669,0.0925920182,0.1001240695,0.1076587055,
0.1162634409,0.1227202233,0.1313275434,0.1388544251,0.1463864764,0.1528380893,0.1625206782,0.1689774607,
0.1765146816,0.1851323408,0.1937396609,0.2001964433,0.2077336642,0.215270885,0.2228236146,0.2293114144,
0.2336486766,0.2401364764,0.2466191067,0.2552367659,0.2617038875,0.2703267163,0.2778742763,0.2854218362,
0.2940550041,0.3005479735,0.3048852357,0.3081472291,0.3071029777,0.3028380893,0.2974979322,0.2900124069,
0.2825217122,0.2750206782,0.2675248139,0.26002378,0.2514578164,0.2450372208,0.2375413565,0.2289547146,
0.2225341191,0.2134279363,0.206461952,0.1989712572,0.1914753929,0.183974359,0.1764784946,0.167912531,
0.1604218362,0.1540064103,0.1465105459,0.1400951199,0.1336848635,0.1283395368,0.1219292804,0.1176592225,
0.1112489661,0.1069840778,0.1027140199,0.0984491315,0.0941842432,0.0899245244,0.0856596361,0.0824700165,
0.079280397,0.0760907775,0.0739764268,0.0697115385,0.0665219189,0.0644075682,0.0612231183,0.0580334988,
0.0559191481,0.0537996278,0.0506151778,0.0474203888,0.0453060381,0.0421215881,0.0405448718,0.0395109595,
0.0379342432,0.0347394541,0.0326251034,0.0305107527,0.0294768404,0.0273624897,0.025248139,0.0252843259,
0.0242504136,0.0221360629,0.0210918114,0.0200527295,0.020094086,0.0190498346,0.0169406534,0.0169768404,
0.0159377585,0.0159739454,0.0138544251,0.0149710505,0.0139371381,0.0128928867,0.0129290736,0.0118899917,
0.0108534946,0.0108922663,0.0098531845,0.0098842018,0.0088451199,0.0078060381};
   
  //Look up the entry of this wavelength
  G4double PDE = 0;
  for(G4int i = 0; i < ENTRY_NUMBER; i++)
  {
    //Look up ascending wavelengths, so our value will be between i-1 and i
    if (wavelength_nm < photon_wavelength_array[i])
    {
      //Interpolation
      PDE = PDE_array[i-1] + (1-(photon_wavelength_array[i] - wavelength_nm)/(photon_wavelength_array[i] - photon_wavelength_array[i-1]))*(PDE_array[i]-PDE_array[i-1]);
      fNPhotons = fNPhotons + PDE;
      return;
    }
  }
}

void PhantomRunAction::BeginOfRunAction(const G4Run*)
{
  fNPhotons = 0;
  fDose = 0;
  fDose2 = 0;
  fNKill = 0;
  fPhotonCount = 0;
}

namespace {
  G4Mutex runActionMutex = G4MUTEX_INITIALIZER;
}

void PhantomRunAction::EndOfRunAction(const G4Run* run)
{
  G4int nofEvents = run->GetNumberOfEvent();
  if (nofEvents == 0) return;
  
  //Define the rms dose
  G4double rms = sqrt(fDose2/nofEvents);

  G4String runType;
  if (G4Threading::IsWorkerThread()) {
    
    runType = "Local Run-";
    // Merge to master counter
    G4AutoLock lock(&runActionMutex);  // For duration of scope.
    fpMasterRunAction->fNPhotons += fNPhotons;
    fpMasterRunAction->fDose += fDose;
    fpMasterRunAction->fDose2 += fDose2;
    fpMasterRunAction->fNKill += fNKill;
    fpMasterRunAction->fPhotonCount += fPhotonCount;
    //G4cout << fDose2;

  } else {
    runType = "Global Run";
    
    //Print to file: "std::ios::app" adds data onto the end of file
    std::ofstream output("photon_Edep.txt", std::ios::app); 
    //If the node is triggered to be outside (outside = 1) photon count is -1
    output << fNPhotons << "," << fPhotonCount << "," << fDose * 1.e12 << "," << rms * 1.e12 << std::endl;
    output.close();
  }

  
 /* G4cout
  << "\n----------------------End of " << runType << "------------------------"
  << "\n The run consists of " << nofEvents << " events."
  << "\n Number of photons reaching the sensitive detector: "
  << fNPhotons
  << "\n With a dose of: "
  << G4BestUnit(fDose, "Dose") << " +- " << G4BestUnit(rms, "Dose")
  << G4endl
  << "\n------------------------------------------------------------"
  << G4endl;*/
}

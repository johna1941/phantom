//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
//----------------------------------------------------------------------------
//
// ClassName:   PhantomOpticalPhysicsMessenger
//
// Author:      P.Gumplinger 30.09.2009 //
//
// Modified:    P.Gumplinger 29.09.2011
//              (based on code from I. Hrivnacova)
//
//----------------------------------------------------------------------------
//

#include "PhantomDetectorConstructionMessenger.hh"
#include "PhantomDetectorConstruction.hh"

#include "G4UIcommand.hh"
#include "G4UIdirectory.hh"

#include "G4UIcommand.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithADouble.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIparameter.hh"

#include "G4SystemOfUnits.hh"
#include "G4UnitsTable.hh"

#include "G4ParticleTable.hh"
#include "G4ProcessManager.hh"
#include "G4ParticleDefinition.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

PhantomDetectorConstructionMessenger::PhantomDetectorConstructionMessenger(
                                            PhantomDetectorConstruction* phantom_detector_construction)
  : G4UImessenger(),
    fDetectorConstruction(phantom_detector_construction),
    fcable_length_cmd(0), 
    fshield_length_cmd(0),
    fvoxel_half_side_cmd(0),
    fbend_radius_cmd(0),
fbirk_constant_cmd(0),
febirk_constant_cmd(0),
fcore_RI_cmd(0),
fclad_RI_cmd(0),
fshield_RI_cmd(0),
fscint_abs_length_cmd(0),
fescint_abs_length_cmd(0)
{
    //Define units for Birk's constant
    new G4UnitDefinition ("um/MeV" , "um/MeV", "Birk", um/MeV);
    new G4UnitDefinition ("mm/MeV", "mm/MeV", "Birk", mm/MeV );
    new G4UnitDefinition ("nm/MeV" , "nm/MeV", "Birk", nm/MeV);
    
    G4bool toBeBroadcasted = false;
    fDir = new G4UIdirectory("/design/",toBeBroadcasted);
    fDir->SetGuidance("Commands related to changing the phantom geometry.");

    fcable_length_cmd = new G4UIcmdWithADoubleAndUnit("/design/changeCableLength", this);
    fcable_length_cmd->SetGuidance("Set the length of the cable");
    fcable_length_cmd->SetParameterName("ShieldLength", false);

    fshield_length_cmd = new G4UIcmdWithADoubleAndUnit("/design/changeShieldLength", this);
    fshield_length_cmd->SetGuidance("Set the length of the shield");
    fshield_length_cmd->SetParameterName("ShieldLength", false);

    fvoxel_half_side_cmd = new G4UIcmdWithADoubleAndUnit("/design/changeVoxelHalfSideLength", this);
    fvoxel_half_side_cmd->SetGuidance("Set the length of the voxel size");
    fvoxel_half_side_cmd->SetParameterName("ShieldLength", false);

    fbend_radius_cmd = new G4UIcmdWithADoubleAndUnit("/design/changeBendRadius", this);
    fbend_radius_cmd->SetGuidance("Set the length of the shield");
    fbend_radius_cmd->SetParameterName("ShieldLength", false);

    fbirk_constant_cmd = new G4UIcmdWithADoubleAndUnit("/design/changeBirksConstant", this);
    fbirk_constant_cmd->SetGuidance("Set the value of the scintillator Birk's Constant");
    fbirk_constant_cmd->SetParameterName("ShieldLength", false);

    febirk_constant_cmd = new G4UIcmdWithADoubleAndUnit("/design/changeBirksConstantError", this);
    febirk_constant_cmd->SetGuidance("Set the value of the scintillator Birk's Constant");
    febirk_constant_cmd->SetParameterName("ShieldLength", false);

    fcore_RI_cmd = new G4UIcmdWithADouble("/design/changeCoreRefractiveIndex", this);
    fcore_RI_cmd->SetGuidance("Set the value of the refractive index of the fibre optic cable core");
    fcore_RI_cmd->SetParameterName("ShieldLength", false);

    fclad_RI_cmd = new G4UIcmdWithADouble("/design/changeCladdingRefractiveIndex", this);
    fclad_RI_cmd->SetGuidance("Set the value of the refractive index of the fibre optic cable cladding");
    fclad_RI_cmd->SetParameterName("ShieldLength", false);

    fshield_RI_cmd = new G4UIcmdWithADouble("/design/changeShieldRefractiveIndex", this);
    fshield_RI_cmd->SetGuidance("Set the value of the glass shield's refractive index");
    fshield_RI_cmd->SetParameterName("ShieldLength", false);

    fscint_abs_length_cmd = new G4UIcmdWithADoubleAndUnit("/design/changeScintAbsorptionLength", this);
    fscint_abs_length_cmd->SetGuidance("Set the value of the absorption length of the scintillator");
    fscint_abs_length_cmd->SetParameterName("ShieldLength", false);

    fescint_abs_length_cmd = new G4UIcmdWithADoubleAndUnit("/design/changeScintAbsorptionLengthError", this);
    fescint_abs_length_cmd->SetGuidance("Set the value of the absorption length of the scintillator");
    fescint_abs_length_cmd->SetParameterName("ShieldLength", false);
}

PhantomDetectorConstructionMessenger::~PhantomDetectorConstructionMessenger()
{
// Destructor

  delete fDir;
  delete fcable_length_cmd;
  delete fshield_length_cmd;
  delete fvoxel_half_side_cmd;
  delete fbirk_constant_cmd;
  delete febirk_constant_cmd;
  delete fbend_radius_cmd;
  delete fcore_RI_cmd;
  delete fclad_RI_cmd;
  delete fshield_RI_cmd;
  delete fscint_abs_length_cmd;
  delete fescint_abs_length_cmd;
}

#include <iostream>
void PhantomDetectorConstructionMessenger::SetNewValue(G4UIcommand* command,
                                            G4String newValue)
{
/// Apply command to the associated object.
if (command == fcable_length_cmd) {
    G4cout << "Cable Length: " << fDetectorConstruction->get_cable_length() << G4endl;
    fDetectorConstruction->set_cable_length(fcable_length_cmd->GetNewDoubleValue(newValue));
    G4cout << "Cable Length: " << fDetectorConstruction->get_cable_length() << G4endl;
   // cable_length = fcable_length_cmd->GetNewDoubleValue(newValue);
  }
  else if (command == fshield_length_cmd) {
    fDetectorConstruction->set_shield_length(fshield_length_cmd->GetNewDoubleValue(newValue));
  }
  else if (command == fvoxel_half_side_cmd) {
    fDetectorConstruction->set_voxel_half_side(fvoxel_half_side_cmd->GetNewDoubleValue(newValue));  
  }
  else if (command == fbend_radius_cmd) {
    fDetectorConstruction->set_bend_radius(fbend_radius_cmd->GetNewDoubleValue(newValue));  
  }
  else if (command == fbirk_constant_cmd) {
    fDetectorConstruction->set_birk_constant(fbirk_constant_cmd->GetNewDoubleValue(newValue));  
  }
  else if (command == febirk_constant_cmd) {
    fDetectorConstruction->set_ebirk_constant(febirk_constant_cmd->GetNewDoubleValue(newValue));  
  }
  else if (command == fcore_RI_cmd) {
    fDetectorConstruction->set_core_RI(fcore_RI_cmd->GetNewDoubleValue(newValue));  
  }
  else if (command == fclad_RI_cmd) {
    fDetectorConstruction->set_clad_RI(fclad_RI_cmd->GetNewDoubleValue(newValue));  
  }
  else if (command == fshield_RI_cmd) {
    fDetectorConstruction->set_shield_RI(fshield_RI_cmd->GetNewDoubleValue(newValue));  
  }
  else if (command == fscint_abs_length_cmd) {
    fDetectorConstruction->set_scint_abs_length(fscint_abs_length_cmd->GetNewDoubleValue(newValue));  
  }
  else if (command == fescint_abs_length_cmd) {
    fDetectorConstruction->set_escint_abs_length(fescint_abs_length_cmd->GetNewDoubleValue(newValue));  
  }

}

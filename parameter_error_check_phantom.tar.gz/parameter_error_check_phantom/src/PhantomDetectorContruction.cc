#include "PhantomDetectorConstruction.hh"

#include "G4RunManager.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4Orb.hh"
#include "G4Tubs.hh"
#include "G4Sphere.hh"
#include "G4Torus.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "G4UnitsTable.hh"
#include "G4PhysicalConstants.hh"
#include "G4VisAttributes.hh"
#include "G4OpticalSurface.hh"
#include "G4LogicalSkinSurface.hh"
#include "G4LogicalBorderSurface.hh"
#include "PhantomSensitiveDetector.hh"
#include "PhantomRunAction.hh"
#include "G4SDManager.hh"
#include "PhantomDetectorConstructionMessenger.hh"

//Constructor - assigns initial mean values to parameters (can be altered by messenger), and initialise errors on the parameters (the variables marked with an e in front).
PhantomDetectorConstruction::PhantomDetectorConstruction()
: fpFibre_log(0)
, fpFibre_phys(0)
, fscint_log(0)
, fscint_phys(0)
, EJ309_Birks_Constant(161.*um/MeV)
, EJ309_abs_length(1.*m)
, core_RI(1.4585)
, clad_RI(1.4108) //HARD FIBRE CABLE 1.4108 //PLASTIC FIBRE CABLE 1.4081 //QUARTZ FIBRE CABLE 1.4418
, shield_RI(1.5354)
, cable_length(1.*cm)
, shield_length(0.1*cm)
, voxel_half_side(0.25*cm)
, bend_radius(0.5*mm)
, core_rad(300.*um)
, clad_rad(330.*um)
, eEJ309_Birks_Constant(0)
, eEJ309_abs_length(0)
, ecore_RI(0)
, eclad_RI(0)
, eshield_RI(0)
, ecable_length(0)
, eshield_length(0)
, evoxel_half_side(0)
, ebend_radius(0)
, ecore_rad(0)
, eclad_rad(0)
{ fMessenger = new PhantomDetectorConstructionMessenger(this);}

PhantomDetectorConstruction::~PhantomDetectorConstruction()
{ delete fMessenger;}

//Function to return a random number drawn from a Gaussian distribution
G4double rand_normal(G4double mean, G4double stddev)
{//Box muller method
    static G4double n2 = 0.0;
    static G4int n2_cached = 0;
    if (!n2_cached)
    {
        G4double x, y, r;
        do
        {
            x = 2.0*rand()/RAND_MAX - 1;
            y = 2.0*rand()/RAND_MAX - 1;

            r = x*x + y*y;
        }
        while (r == 0.0 || r > 1.0);
        {
            G4double d = sqrt(-2.0*log(r)/r);
            G4double n1 = x*d;
            n2 = y*d;
            G4double result = n1*stddev + mean;
            n2_cached = 1;
            return result;
        }
    }
    else
    {
        n2_cached = 0;
        return n2*stddev + mean;
    }
}

//Absolute value for G4double
G4double G4abs(G4double test)
{
  if (test > 0 ) {return test;}
  else {return -test;}
}

//Construct function, called to define the user geometry, materials, properties, etc.
G4VPhysicalVolume* PhantomDetectorConstruction::Construct()
{
  //Apply Gaussian uncertainties to our parameters
  G4double EJ309_Birks_Constant_val = G4abs(rand_normal(EJ309_Birks_Constant, eEJ309_Birks_Constant));
  G4double EJ309_abs_length_val = G4abs(rand_normal(EJ309_abs_length, eEJ309_abs_length));
  G4double core_RI_val = G4abs(rand_normal(core_RI, ecore_RI));
  G4double clad_RI_val = G4abs(rand_normal(clad_RI, eclad_RI));
  G4double shield_RI_val = G4abs(rand_normal(shield_RI, eshield_RI));
  G4double cable_length_val = G4abs(rand_normal(cable_length, ecable_length));
  G4double shield_length_val = G4abs(rand_normal(shield_length, eshield_length));
  G4double voxel_half_side_val = G4abs(rand_normal(voxel_half_side, evoxel_half_side));
  G4double bend_radius_val = G4abs(rand_normal(bend_radius, ebend_radius));
  G4double core_rad_val = G4abs(rand_normal(core_rad, ecore_rad));
  G4double clad_rad_val = G4abs(rand_normal(clad_rad, eclad_rad));

  G4cout << "Birks constant: " << EJ309_Birks_Constant_val*1e3 << " um/MeV" << G4endl;
  G4cout << "Absorption length: " << EJ309_abs_length_val/1e3 << " m" << G4endl;

  // Useful names
  G4String name, symbol;
  G4double density;
  G4int ncomponents, natoms;
  G4double fractionmass;
  //  G4UnitDefinition::BuildUnitsTable();  ??
  G4bool checkOverlaps = true;

  // Materials
  G4NistManager* nist = G4NistManager::Instance();
  G4Material* world_mat = nist->FindOrBuildMaterial("G4_AIR");
  //  G4Material* env_mat = nist->FindOrBuildMaterial("G4_WATER");
  G4Element* C = nist->FindOrBuildElement("C");
  G4Element* H = nist->FindOrBuildElement("H");
  G4Element* N = nist->FindOrBuildElement("N");
  G4Element* O = nist->FindOrBuildElement("O");
  G4Element* Si = nist->FindOrBuildElement("Si");
   
  //Air material with optical processes
  const G4int ENTRY_NUMBER_AIR = 3;
  G4double temp_energies_air[ENTRY_NUMBER_AIR] = {2.00*eV, 3.00*eV, 5.00*eV};
  //Create material properties table
  G4double ref_air[ENTRY_NUMBER_AIR] = {1.000277, 1.000277, 1.000277}; //1.4585
  G4MaterialPropertiesTable* air_mpt = new G4MaterialPropertiesTable();
  air_mpt -> AddProperty("RINDEX", temp_energies_air, ref_air, ENTRY_NUMBER_AIR)->SetSpline(true);
 
  //Assign material property tables to materials
  world_mat->SetMaterialPropertiesTable(air_mpt);

  //Styrene
  G4Material* styrene = new G4Material(name = "Styrene", density=0.909*g/cm3, ncomponents=2);
  styrene->AddElement(C, natoms=8);
  styrene->AddElement(H, natoms=8);
  //1,3-Butadiene
  density = 0.6149*g/cm3; // At 25\degree (solid)
  G4Material* buta = new G4Material(name = "1,3-Butadiene", density, ncomponents=2);
  buta->AddElement(C, natoms=4);
  buta->AddElement(H, natoms=6);
  //Acrylonitrile
  G4Material* acryl = new G4Material(name = "Acrylonitrile", density=0.81*g/cm3, ncomponents=3);
  acryl->AddElement(C, natoms=3);
  acryl->AddElement(H, natoms=3);
  acryl->AddElement(N, natoms=1);
  // ABS
  density = 1.08*g/cm3; //1.06-1.08, according to wikipedia
  G4Material* ABS = new G4Material(name = "ABS", density, ncomponents=3);
  ABS->AddMaterial(styrene, fractionmass=55*perCent); // 40-60%
  ABS->AddMaterial(buta, fractionmass=20*perCent); // 5-30%
  ABS->AddMaterial(acryl, fractionmass=25*perCent); //15-35%

  /////// Construct optical properties of the fibre optic cable //////
  
  //Define the core
  density = 2.32*g/cm3;
  G4Material* glass_core = new G4Material(name = "glass_core", density, ncomponents=2);
  glass_core->AddElement(O, fractionmass=0.532365);
  glass_core->AddElement(Si, fractionmass=0.467435);
  //Cladding
  density = 2.32*g/cm3;
  G4Material* glass_clad = new G4Material(name = "glass_clad", density, ncomponents=2);
  glass_clad->AddElement(O, fractionmass=0.532365);
  glass_clad->AddElement(Si, fractionmass=0.467435); 

  const G4int ENTRY_NUMBER = 3;
  G4double temp_energies[ENTRY_NUMBER] = {2.00*eV, 3.00*eV, 5.00*eV};
  //Create material properties table
  G4double core_n[ENTRY_NUMBER] = {1.*core_RI_val, 1.*core_RI_val, 1.*core_RI_val}; //1.4585
  G4double clad_n[ENTRY_NUMBER] = {1.*clad_RI_val, 1.*clad_RI_val, 1.*clad_RI_val}; //QUARTZ FIBRE CABLE //1.4418
  G4MaterialPropertiesTable* clad_mpt = new G4MaterialPropertiesTable();
  clad_mpt -> AddProperty("RINDEX", temp_energies, clad_n, ENTRY_NUMBER)->SetSpline(true);
  G4MaterialPropertiesTable* core_mpt = new G4MaterialPropertiesTable();
  core_mpt -> AddProperty("RINDEX", temp_energies, core_n, ENTRY_NUMBER)->SetSpline(true);

  //Assign material property tables to materials
  glass_core->SetMaterialPropertiesTable(core_mpt);
  glass_clad->SetMaterialPropertiesTable(clad_mpt);

  ////////// Shield logical volume ///////
  density = 2.51*g/cm3;
  G4Material* D263_T = new G4Material(name = "D263_T", density, ncomponents=2);
  D263_T->AddElement(O, fractionmass=0.532365);
  D263_T->AddElement(Si, fractionmass=0.467435);
  const G4int ENTRY_NUMBER_SHIELD = 9;
  G4double temp_energies_shield[ENTRY_NUMBER_SHIELD] = {1.89*eV, 1.93*eV, 2.10*eV, 2.11*eV, 2.27*eV, 2.55*eV, 2.58*eV, 2.84*eV, 5.*eV};
  G4double shield_n[ENTRY_NUMBER_SHIELD] = {1.*shield_RI_val, 1.*shield_RI_val, 1.*shield_RI_val, 1.*shield_RI_val, 1.*shield_RI_val, 1.*shield_RI_val, 1.*shield_RI_val, 1.*shield_RI_val, 1.*shield_RI_val};
  G4MaterialPropertiesTable* shield_mpt = new G4MaterialPropertiesTable();
  shield_mpt -> AddProperty("RINDEX", temp_energies_shield, shield_n, ENTRY_NUMBER_SHIELD)->SetSpline(true);
  D263_T->SetMaterialPropertiesTable(shield_mpt);

  ////////// Construct LiqScint //////////
  // The atomic composition of our liquid scintillator is simply given as a
  // ratio of H:C (1.33), since there are no other molecules and its simply a
  // percentage mixture of two hydrocarbons
  density = 1.136*g/cm3;
  G4Material* LS = new G4Material(name = "LS", density, ncomponents=2);
  LS->AddElement(C, natoms=3);
  LS->AddElement(H, natoms=4);

  // Optical properties
  G4double photonEnergyRI[] = { 2.034*eV, 4.002*eV, 4.136*eV }; 
  G4double refractiveIndex[] = { 1.57, 1.57, 1.57}; 

  //EJ-309 emission spectrum
  G4double photonEnergySF[] =
  { 3.2641304753*eV,3.2375928291*eV,3.2194719737*eV,3.2055176061*eV,3.1907001133*eV,3.1730989481*eV
,3.1576156961*eV,3.1413294501*eV,3.1195606712*eV,3.099018817*eV,3.064167466*eV,3.038093271*eV
,3.0203681061*eV,3.0089572414*eV,2.9967646505*eV,2.9735272451*eV,2.9498067999*eV,2.928117044*eV
,2.9091941184*eV,2.893745631*eV,2.8808630683*eV,2.8633356935*eV,2.8212048685*eV,2.7937997484*eV
,2.7706239945*eV,2.752212086*eV,2.7326001234*eV,2.7090062448*eV,2.6837278039*eV,2.6575518141*eV
,2.6285407128*eV,2.5897503421*eV,2.5583943335*eV,2.5155057987*eV,2.479363474*eV,2.4396375748*eV
,2.4056277573*eV,2.3790950982*eV,2.3611908478*eV}; //39 entries
  G4double scintilFast[] =
  { 0.0003036577,0.0027881297,0.0061007591,0.0097446515,0.0140510697,0.0195169082,
0.0244858523,0.0283781919,0.0316080055,0.0331815045,0.0344237405,0.0357487923,
0.0379020014,0.040220842,0.042705314,0.0460179434,0.0485024155,0.0491649413,
0.0478398896,0.0436991028,0.0407177364,0.0388957902,0.037405107,0.0361628709,
0.0335955832,0.0312767426,0.0286266391,0.0263077985,0.0240717736,0.0219185645,
0.0196825397,0.0167011732,0.0142995169,0.0103243616,0.0076742581,0.0056866805,
0.0040303658,0.0032022084,0.0030365769};

  G4double absorption[] = 
  { EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, //5
    EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, //10
    EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, //15
    EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, //20
    EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, //25
    EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, //30
    EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, //35
    EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val, EJ309_abs_length_val}; //39

  // Properties of liquid scintillator bulk medium
  const G4int nEntriesSF = sizeof(photonEnergySF)/sizeof(G4double);
  const G4int nEntriesRI = sizeof(photonEnergyRI)/sizeof(G4double);
  // Create material properties table and add properties
  G4MaterialPropertiesTable* scint_mpt = new G4MaterialPropertiesTable();
  // Add to material properties table
  scint_mpt->AddProperty("RINDEX",       photonEnergyRI, refractiveIndex, nEntriesRI)
  ->SetSpline(true);
  scint_mpt->AddProperty("ABSLENGTH",    photonEnergySF,   absorption,      nEntriesSF)
  ->SetSpline(true);
  scint_mpt->AddProperty("FASTCOMPONENT",photonEnergySF,   scintilFast,     nEntriesSF)
  ->SetSpline(true);
  scint_mpt->AddConstProperty("SCINTILLATIONYIELD",12300/MeV);
  scint_mpt->AddConstProperty("RESOLUTIONSCALE",1.0);
  scint_mpt->AddConstProperty("FASTTIMECONSTANT", 3.2*ns); // Given to be 3.2ns in EJ-301 PDF
  //scint_mpt->AddConstProperty("SLOWTIMECONSTANT",32.3*ns); // "First three components; 3.2, 32.3, 270...?"
  //scint_mpt->AddConstProperty("YIELDRATIO",0.8); // Relative strength of the fast vs. slow, i.e. 80% scintillations are fast.
  G4cout << "Scint G4MaterialPropertiesTable\n"; scint_mpt->DumpTable();
  // Associate material properties table with the liquid scintillator material
  LS->SetMaterialPropertiesTable(scint_mpt);

  //Add in Birk's constant for scintillator quenching at high LET
  LS->GetIonisation()->SetBirksConstant (EJ309_Birks_Constant_val);

  // Optical properties of the reflective paint
  G4double photonEnergyRe[] =
  { 3.315*eV, 3.261*eV, 3.208*eV, 3.157*eV,
    3.108*eV, 3.060*eV, 3.014*eV, 2.925*eV,
    2.841*eV, 2.763*eV, 2.688*eV, 2.617*eV,
    2.550*eV, 2.486*eV, 2.426*eV, 2.368*eV,
    2.313*eV, 2.260*eV, 2.210*eV, 2.162*eV,
    2.116*eV, 2.072*eV };

  G4double scale = 1.0;
  G4double reflectivity[] =
   {scale*0.7000, scale*0.8000, scale*0.8700, scale*0.8990,
    scale*0.9200, scale*0.9340, scale*0.9450, scale*0.9550,
    scale*0.9575, scale*0.9600, scale*0.9620, scale*0.9625,
    scale*0.9640, scale*0.9640, scale*0.9640, scale*0.9650,
    scale*0.9650, scale*0.9650, scale*0.9650, scale*0.9645,
    scale*0.9630, scale*0.9620 };

  G4OpticalSurface* scint_surface = new G4OpticalSurface("scint-surface");
  scint_surface->SetType(dielectric_dielectric); // If both surfaces have refractive properties added, this will actually calculate reflection for us
  scint_surface->SetFinish(groundfrontpainted);
  scint_surface->SetModel(unified);
  const G4int nEntriesRe = sizeof(photonEnergyRe)/sizeof(G4double);
  assert(sizeof(reflectivity) == sizeof(photonEnergyRe));
  G4MaterialPropertiesTable* mptForSkin = new G4MaterialPropertiesTable();
  mptForSkin->AddProperty("REFLECTIVITY", photonEnergyRe, reflectivity, nEntriesRe) // Takes photonEnergy, nEntries from liquid scint above. Looks like this is instead of using rindex of a new surface
  ->SetSpline(true);
  G4cout << "Skin G4MaterialPropertiesTable\n"; mptForSkin->DumpTable();
  // Associates the material properties with the surface of the liquid scintillator.
  scint_surface->SetMaterialPropertiesTable(mptForSkin);

  name = "World";
  G4VSolid* world = new G4Box(name,voxel_half_side_val+cable_length_val+bend_radius_val+5.*cm,voxel_half_side_val+bend_radius_val+cable_length_val+5.*cm,voxel_half_side_val+bend_radius_val + 10.*cm);
  G4LogicalVolume* world_log = new G4LogicalVolume(world,world_mat,name);
  world_log->SetVisAttributes(G4VisAttributes::GetInvisible());
  G4VPhysicalVolume* physWorld = new G4PVPlacement(G4Transform3D(),world_log,name,0,false,0);

  name = "Orb";
  G4VSolid* orb = new G4Box(name, voxel_half_side_val+bend_radius_val+1.*cm, voxel_half_side_val+bend_radius_val+1.*cm, voxel_half_side_val+bend_radius_val+1.*cm);
  G4LogicalVolume* orb_log = new G4LogicalVolume(orb,ABS,name);
  forb_phys = new G4PVPlacement(G4Transform3D(),orb_log,name,world_log,false,0,checkOverlaps);
  new G4LogicalSkinSurface("scint_surface", orb_log, scint_surface);

  name = "Scint";
  G4VSolid* scint = new G4Box(name, voxel_half_side_val, voxel_half_side_val, voxel_half_side_val);
  fscint_log = new G4LogicalVolume(scint,LS,name);
  fscint_phys = new G4PVPlacement(G4Transform3D(),fscint_log,name,orb_log,false,0,checkOverlaps);

  name = "Shield";
  G4VSolid* shield = new G4Box(name, voxel_half_side_val,voxel_half_side_val, (shield_length_val/2.));
  fshield_log = new G4LogicalVolume(shield,D263_T,name);
  fshield_phys = new G4PVPlacement
    (G4Translate3D(0., 0., (voxel_half_side_val-(shield_length_val/2.))),fshield_log,name,fscint_log,false,0,checkOverlaps);

  name = "Clad_bend";
  G4VSolid* clad_bend = new G4Torus(name, 0., clad_rad_val,bend_radius_val,-90.*degree,90.*degree);
  G4RotationMatrix * rot_bend = new G4RotationMatrix();
  rot_bend->rotateY(90.*deg);
  G4LogicalVolume* fclad_bend_log = new G4LogicalVolume(clad_bend,world_mat,name);
  G4VPhysicalVolume* fclad_bend_phys = new G4PVPlacement
    (rot_bend, G4ThreeVector(0.,bend_radius_val,voxel_half_side_val),fclad_bend_log,name,orb_log,false,0,checkOverlaps);

  name = "Core_bend";
  G4VSolid* core_bend = new G4Torus(name, 0., core_rad_val,bend_radius_val,-90.*degree,90.*degree);
  G4LogicalVolume* fcore_bend_log = new G4LogicalVolume(core_bend,world_mat,name);
  G4VPhysicalVolume* fcore_bend_phys = new G4PVPlacement
    (G4Translate3D(0.,0.,0.),fcore_bend_log,name,fclad_bend_log,false,0,checkOverlaps);

  name = "Clad";
  G4VSolid* clad = new G4Tubs(name, 0., clad_rad_val, cable_length_val,0.,twopi);
  G4LogicalVolume* fclad_log = new G4LogicalVolume(clad,glass_clad,name);
  G4RotationMatrix * rot_cable = new G4RotationMatrix();
  rot_cable->rotateX(90.*deg);
  G4VPhysicalVolume* fclad_phys = new G4PVPlacement
    (rot_cable, 
    G4ThreeVector(0.,(cable_length_val+bend_radius_val),(bend_radius_val+voxel_half_side_val)),
    fclad_log,name,orb_log,false,0,checkOverlaps);

  name = "Core";
  G4VSolid* core = new G4Tubs(name, 0., core_rad_val, cable_length_val,0.,twopi);
  fcore_log = new G4LogicalVolume(core,glass_core,name);
  fcore_phys = new G4PVPlacement
  (G4Translate3D(0.,0.,0.*cm),fcore_log,name,fclad_log,false,0,checkOverlaps);

  name = "Fibre";
  G4VSolid* fibre = new G4Tubs(name,0.,core_rad_val,0.03*cable_length_val,0.,twopi);
  fpFibre_log = new G4LogicalVolume(fibre,LS,name);
  fpFibre_phys = new G4PVPlacement
  (G4Translate3D(0.,0.,0.9*cable_length_val),fpFibre_log,name,fcore_log,false,0,checkOverlaps);


  return physWorld;
}

void PhantomDetectorConstruction::ConstructSDandField()
{
//  PhantomRunAction* pRunAction =
//  const_cast<PhantomRunAction*>
//  (static_cast<const PhantomRunAction*>
//   (G4RunManager::GetRunManager()->GetUserRunAction()));
//
//  G4VSensitiveDetector* fibreSD = new PhantomSensitiveDetector("Fibre",pRunAction);
//
//  G4SDManager* pSDman = G4SDManager::GetSDMpointer();
//  pSDman->AddNewDetector(fibreSD);
//  fpFibre_log->SetSensitiveDetector(fibreSD);
}

